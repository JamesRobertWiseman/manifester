# Manifester

Manifester is a Codex plugin that builds a small local application for the files and data in a project.

It uses the signed-in Codex session. It does not need an OpenAI API key or change the project's source files.

Codex starts and opens its manager at `http://127.0.0.1:4316` when an application is opened, then closes it when the last active Manifester connection exits. Its React dashboard shows applications as soon as creation begins, retains failures, and monitors, opens, starts, stops, restarts, and inspects completed applications. Each inspector includes persistent generation and server activity plus a link to the application's Codex task.

## OpenAI Build Week judge quick start

Manifester is submitted in the Developer Tools category. Prebuilt plugin artifacts are included under `dist/`, so judges can install and run the project without rebuilding it or installing PNPM.

The submitted build is verified on macOS 26.5.2 with Node.js 24.18.0 and Codex CLI 0.144.6. A signed-in Codex installation and Node.js 24 or later are required. Other platforms are not claimed by this submission.

1. Clone or download this repository and open a terminal in its root.
2. Install the prebuilt plugin:

   ```sh
   codex plugin marketplace add .
   codex plugin add manifester@manifester-local
   ```

3. Restart Codex or open a new Codex task.
4. Open `examples/task-management` as the project folder and ask:

   > Create the most useful application for the data in this project.

5. Watch the manager at `http://127.0.0.1:4316`. The application appears there as soon as generation begins, then opens automatically when it is ready.
6. Choose `View` or `Plan` in the generated task application. The first use displays `Generating view...`, validates the new route, and opens it. Later uses reuse that route.
7. Change a task, restart it from the manager, and confirm the edit remains while `tasks.csv` is unchanged.

Generation uses the judge's signed-in Codex session and can take a few minutes. Progress and failures remain visible in the manager instead of leaving an indefinite loading state. See [DEMO.md](DEMO.md) for the complete three-minute demonstration path.

### Included sample projects

| Project | Data | Purpose |
| --- | --- | --- |
| `examples/task-management` | `tasks.csv` | Primary judge flow for generation, just-in-time routes, edits, and restart persistence |
| `examples/underwriting-system` | `applications.json` | Second domain for checking that generation follows the data rather than a fixed demo template |

## How Codex and GPT-5.6 are used

Manifester runs GPT-5.6 through the signed-in Codex SDK. A read-only, network-disabled discovery task interprets the project's files and selects the most useful workflow. A separate workspace-limited task generates the initial vanilla application. Later Codex tasks add and review deeper routes only when the user first chooses their actions. Natural-language refinements use the same staged validation path.

Codex also accelerated development of Manifester itself: it helped refactor the PNPM workspace, separate the plugin, MCP, server, CLI, and runner packages, diagnose lifecycle failures, validate generated application contracts, exercise the React manager in a real browser, and repeat clean packaging and installation checks.

The key product decisions are deliberate:

- Original project files stay read-only; application edits go to a local SQLite copy.
- Generated changes are validated in staging before they replace the working application.
- The initial application is useful immediately without predicting every future screen.
- Deeper routes materialise from demonstrated user intent and are then cached.
- Publishing produces a fixed Sites project only after every deferred action has been opened.

## How it works

1. Manifester discovers the useful files in the open project.
2. A read-only Codex pass works out what the data means, how it fits together, who it is for, and which application would be most useful.
3. If confidence is below 65 percent, Manifester asks up to three short questions through Codex's native question form. Otherwise it continues automatically.
4. A separate design and build pass creates only the custom home page and its deferred actions.
5. Manifester imports supported data into a local SQLite database, starts the local server, and returns the application address.
6. Codex opens the application in its in-app browser and checks the home page without generating deeper routes.

The generated application is stored in `.manifester/app`. Each application keeps its local data in `.manifester/data.sqlite`. Record edits survive application changes, stops, restarts, and Manifester schema upgrades. Ordered SQLite migrations run automatically when an application opens, and the database is never removed as part of an upgrade.

## Just-in-time features

The initial application contains only its home route. Its most useful starting actions stay deferred until the user chooses them. Entering any safe application URL is also a generation intent, even when no existing control points to it yet.

When the user first chooses one of these actions or opens an unknown safe URL, Manifester sends the validated intent to Codex. Codex creates the needed view, route, local endpoint, and navigation from affected existing views, then reviews the generated result and fixes validation findings. Only a reviewed result can replace the working application. Later uses reuse the generated feature.

While a feature is being created, every generated application shows the same small loader:

> Generating view...

The loader blocks repeated clicks and is announced to assistive technology. If generation fails, the current application stays available and the user can try again or go back.

## Publish to ChatGPT Sites

After every deferred feature has been opened and checked, ask Codex:

> Publish this app to ChatGPT Sites.

Manifester warns that the hosted site is a fixed version and will not generate new views on demand. The manager inspector shows whether unresolved features still need to be opened. Publish to Sites opens a new Codex task in the application project with the Manifester publishing workflow ready to send. Only the prepared `.manifester/site` project is deployed; Manifester's internal files and local SQLite store remain local.

## Local data and safety

- CSV, JSON, XLSX, and XLSM tables are imported into the local SQLite database.
- Relevant text, Markdown, code, and configuration files may provide read-only context for discovery.
- Create, edit, and delete actions change only the local SQLite copy.
- Original project files remain unchanged.
- Local changes and generated features remain available after a server restart.
- If a source file changes, Manifester stops before using stale local data and asks the user to rebuild or reset.
- Unsupported files and skipped large files are reported honestly.
- Direct URL generation rejects reserved API paths, encoded path separators, traversal segments, control characters, empty segments, and oversized paths before Codex is called.

## Use it

Open the project directory in Codex and ask:

> Create the most useful application for the data in this project.

Manifester will inspect the project, ask native questions only when needed, build the application, start it, and open it in Codex's in-app browser.

After using the application, ask Codex for changes in everyday language, for example:

> Add a calendar view for upcoming work.

Manifester updates a staging copy, checks it, publishes it, and reloads the running application. It keeps the last working version if the change cannot be built.

## Manager lifecycle

Codex starts the manager automatically. Closing Codex closes the manager and its running application servers. Applications marked as running are restored when Codex starts again.

The plugin installs the `mnf` command globally the first time it runs. Control the dashboard from any directory:

```sh
mnf dash status
mnf dash start
mnf dash stop
mnf dash restart
mnf dash open
```

When Codex is open, a terminal-started dashboard remains owned by Codex and closes with it. Without Codex, `start` runs it independently until `stop` is used.

Applications can be removed from the dashboard without deleting their generated files or SQLite data. The separate permanent delete action removes the complete `.manifester` folder only after an explicit confirmation.

## MCP tools

- `open_manifester_manager()` opens the standalone management dashboard.
- `open_manifester_application({ project, port? })` discovers, builds, starts, or reopens an application.
- `change_manifester_application({ project, instruction })` adds or changes a feature.
- `get_manifester_status({ project })` reports whether the application is ready, generating, running, or blocked by changed source files.
- `restart_manifester_application({ project, port? })` restarts the server, keeps local state, and reopens the application.
- `close_manifester_application({ project })` stops the local server and keeps generated state.
- `reset_manifester_application({ project })` removes only the project's `.manifester` directory, including local edits.

## Runtime requirements

- Node.js 24 or later
- Codex installed and signed in
- macOS for the verified Build Week submission path

When `PNPM_HOME` or `~/.local/bin` is already on `PATH`, the plugin also installs the optional global `mnf` command there.

No API key or environment file is required.

## Contributor requirements

- Node.js 24 or later
- pnpm 11.13.0
- Codex installed and signed in

## Build the plugin

```sh
pnpm clean:install
```

This installs the dependencies, checks the TypeScript source, and builds the self-contained plugin.
Vite bundles and minifies every distributable artifact under `dist/`, grouped by runtime. Do not edit generated files directly.

For later changes:

```sh
pnpm verify
```

## Install it in Codex

From the repository root:

```sh
codex plugin marketplace add .
codex plugin add manifester@manifester-local
```

Restart Codex or open a new Codex task after installation so the plugin skills and MCP tools are loaded.

## Architecture

```text
Codex conversation
  -> Manifester skills
  -> bundled MCP server
  -> Codex-owned local manager and dashboard
  -> read-only project discovery
  -> Codex design and generation
  -> vanilla application in .manifester/app
  -> local server and SQLite data
```

The repository root is the plugin distribution shell for its manifest, skills, assets, and generated artifacts. All production source lives under `packages/`: `plugin` owns the shared application core, while `mcp`, `server`, `cli`, and `api-runner` own their named runtimes. Vite builds every package and generated runtime artifact.

Generated applications remain independent of the manager dashboard. They have no shared React renderer, fixed component library, external CDN, or separate frontend build.
