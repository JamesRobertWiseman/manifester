# OpenAI Build Week demo

Target length: 2 minutes 45 seconds. The final video must be public on YouTube, remain under 3 minutes, and include voiceover explaining Manifester, Codex, and GPT-5.6.

## Recording path

| Time | Screen | Voiceover |
| --- | --- | --- |
| 0:00 | `examples/task-management/tasks.csv` | Useful operational data often sits in files, but building a tailored application around it takes time. Manifester turns project data into a local app with one Codex prompt. |
| 0:15 | New Codex task and the creation prompt | Manifester is a Codex plugin. It uses the signed-in Codex session and GPT-5.6, so there is no API key or separate account setup. |
| 0:30 | Manager showing live generation progress | GPT-5.6 first performs read-only discovery to understand the data and choose the most useful workflow. A separate isolated task generates and validates the entry experience. |
| 0:50 | Generated task application | The result is shaped by the dataset, not a fixed dashboard template. The original CSV remains unchanged and the app works against a local SQLite copy. |
| 1:10 | Choose `View` and show `Generating view...` | Manifester does not build every possible screen upfront. This task detail is being materialised just in time because I asked for it. |
| 1:30 | Generated task detail | The route was generated in staging, reviewed, validated, and then published into the running local app. Opening it again reuses the generated route. |
| 1:48 | Edit a task, restart from the manager, reopen it | Local edits survive application and manager restarts while the source data stays read-only. |
| 2:08 | Manager activity, application task link, and Sites readiness | The React manager exposes progress, failures, lifecycle controls, and the correct Codex task for each application. It also prevents a fixed Sites publish until every feature has been generated. |
| 2:30 | Application and Manifester banner | Codex accelerated the plugin architecture, debugging, generated-app validation, browser QA, and packaging. Manifester shows how GPT-5.6 can turn intent and existing data into software that grows as it is used. |

## Recording checklist

- Use only the included sample data.
- Hide notifications, account details, local paths, environment files, and unrelated browser tabs.
- Label shortened generation waits as time jumps.
- Show one real first-use route generation and one cached revisit.
- Show one persisted edit after restart.
- Confirm the final upload is public, has voiceover, and is shorter than 3 minutes.
- Add the YouTube URL to the Devpost project before submission.
